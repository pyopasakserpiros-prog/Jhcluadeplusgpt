'use strict';
const G = require('../test/load.js');
const { JD, WILD } = G;
const species = JD.BEASTS.species.filter(s => s.id.startsWith('ECO2_'));
console.log('Total ECO2 species:', species.length);

const inPools = new Map();
for (const [zid, z] of Object.entries(WILD.zones)) {
  for (const p of z.pools || []) {
    for (const sid of p.speciesIds || []) {
      if (!inPools.has(sid)) inPools.set(sid, []);
      inPools.get(sid).push({ zid, pid: p.id, pmin: p.min, pmax: p.max, zmin: z.min, zmax: z.max });
    }
  }
}

const missing = [];
const tierMismatch = [];
const aquaticOnLand = [];

for (const s of species) {
  const pools = inPools.get(s.id);
  if (!pools || !pools.length) {
    missing.push(s.id);
  } else {
    for (const p of pools) {
      if (s.tier < p.pmin || s.tier > p.pmax) {
        tierMismatch.push({ id: s.id, tier: s.tier, pmin: p.pmin, pmax: p.pmax, pid: p.pid });
      }
      if (s.terrain === 'water' || s.archetype === 'AQUATIC') {
        aquaticOnLand.push({ id: s.id, zid: p.zid, pid: p.pid });
      }
    }
  }
}

console.log('Missing from map pools:', missing);
console.log('Tier mismatches:', tierMismatch);
console.log('Aquatic in map pools:', aquaticOnLand);
