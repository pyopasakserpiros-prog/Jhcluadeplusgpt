'use strict';
const { spawnSync } = require('child_process');
const path = require('path');
const root = path.join(__dirname, '..');
const r = spawnSync('python3', [path.join(root, 'tools/package_release.py')], {
  cwd: root,
  encoding: 'utf8'
});
if (r.stdout) console.log(r.stdout.trim());
if (r.stderr) console.error(r.stderr.trim());
if (r.status !== 0) {
  process.exit(r.status || 1);
}
console.log('PASS: package_release.py executed and verified successfully');
