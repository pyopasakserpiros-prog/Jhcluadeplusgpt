'use strict';
const { spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const root = path.join(__dirname, '../..');
const run = cmd => {
  console.log(`$ ${cmd}`);
  const r = spawnSync('sh', ['-c', cmd], { cwd: root, encoding: 'utf8' });
  if (r.stdout) console.log(r.stdout.trim());
  if (r.stderr) console.error(r.stderr.trim());
  return r.status;
};

// Clean up temporary scratch scripts
const tempFiles = [
  'tools/check_exped.js',
  'tools/check_fam_terr.js',
  'tools/check_map.js',
  'tools/check_water_tiles.js',
  'tools/find_apply.js',
  'tools/find_hunt.js',
  'tools/find_poison.js',
  'tools/find_st.js',
  'tools/find_terms.js',
  'tools/find_ui_eco.js',
  'tools/find_water.js',
  'tools/list_sim.js'
];
tempFiles.forEach(f => {
  const p = path.join(__dirname, '..', f);
  if (fs.existsSync(p)) fs.unlinkSync(p);
});

run('git branch -v');
run('git status --short');
run('git diff --check');

