'use strict';
const path = require('path');
process.argv[2] = '360';
process.argv[3] = 'ecology-sim-seed-360';
process.argv[4] = path.join(__dirname, 'results/long_ecology_360d.json');
require('./long_ecology_simulation.js');
setTimeout(() => process.exit(0), 100);

