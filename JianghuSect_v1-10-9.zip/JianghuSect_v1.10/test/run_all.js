'use strict';
const {spawnSync}=require('child_process'),fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..'),results=[];
const tests=['core_lock','cp_economy','speed_controls','time_controls','runtime_timing','craft_transactions','content_expansion','content_economy','content_discovery','exploration_replay','ui_content','legacy_save','beast_ecology','external_market','recipe_scroll_lifecycle','specialization_tracks','combat_passives','coherent_regions_recipes','welfare_production_policies','browser_mobile_perf','demon_heartsoul_paths','organs_experiments_politics','standalone','recipe_coverage'];
for(const test of tests){const r=spawnSync(process.execPath,[path.join(__dirname,test+'.js')],{cwd:root,encoding:'utf8',timeout:60000});results.push({test,status:r.status===0?'PASS':'FAIL',exitCode:r.status,output:(r.stdout+r.stderr).trim()});console.log(results.at(-1).status+' '+test);}
const paths=['data','js','tools','test'].flatMap(d=>fs.readdirSync(path.join(root,d)).filter(n=>n.endsWith('.js')).map(n=>path.join(root,d,n)));
const syntax=paths.map(p=>{const r=spawnSync(process.execPath,['--check',p],{encoding:'utf8'});return {file:path.relative(root,p),ok:r.status===0,error:r.stderr};});
results.push({test:'syntax',status:syntax.every(r=>r.ok)?'PASS':'FAIL',files:syntax.length,failures:syntax.filter(r=>!r.ok)});
fs.mkdirSync(path.join(__dirname,'results'),{recursive:true});fs.writeFileSync(path.join(__dirname,'results/assertions.json'),JSON.stringify({date:'2026-10-27',node:process.version,results},null,2)+'\n');
console.log('Assertions: '+results.filter(r=>r.status==='PASS').length+'/'+results.length+' groups passed.');
if(results.some(r=>r.status!=='PASS'))process.exitCode=1;
