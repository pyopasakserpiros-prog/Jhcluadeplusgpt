# JianghuSect v1.10.12 — Combined Handoff (NPC Overhaul + Graphics Overhaul + Visitors, Living Clues & Legendary Weapons)

## 1. Overview of Completed Work

This package contains the complete, cumulative implementation of all three major development phases in this conversation:

1. **Phase I — NPC Life, Cognition, Relationships, Goals & Authority Overhaul (`v1.10.11` / `1.12.0`)**:
   - Autonomous 100-bed dormitory progression (`56 + 28 + 16 = 100`), applicant talent tiers & Observable Capability Assessment (`CA`), 5-axis asymmetric relationships (`affinity`, `respect`, `trust`, `gratitude`, `fear`), long-term aspirations & mid-term goals, authority/delegation chains, and single-pass positional log linkification.
   - Reports: `docs/NPC_ARCHITECTURE_AND_CODE_MAP.md`, `docs/NPC_BUG_FIX_AND_DESIGN_REPORT.md`, `docs/NPC_TEST_AND_SIMULATION_RESULTS.md`.
2. **Phase II — Graphics, Visual Readability & Mobile UI Overhaul (`v1.10.12`)**:
   - Wuxia scroll/jade visual identity (`css/style.css`, `js/render.js`, `js/ui.js`), renderer-owned `apCache` (eliminating `n._ap` mutation), pure read-only legendary aura inspection (`R.readOnlyActivePassives`, eliminating `n.passiveLoadout` mutation during `R.draw`), 2-tier cached building sprites (`this.buildingSprites`), viewport-culled night lighting, and paused-mode (`0×`) render throttling.
   - Reports & Patch: `docs/GRAPHICS_IMPLEMENTATION_REPORT.md`, `docs/GRAPHICS_CODE_MAP.md`, `docs/CODEX_GRAPHICS_REVIEW_HANDOFF.md`, `docs/graphics_update.patch`, `test/results/graphics_before_manifest.json`, `test/results/graphics_after_manifest.json`, and 9 before/after screenshot pairs in `test/results/screenshots/`.
3. **Phase III — Visitors, Living Clues, Inheritance Stories & Legendary Weapons Overhaul (`v1.10.12` / `1.12.1`)**:
   - **Persistent Outsider / Visitor Ecology (`js/visitors_clues.js`)**: Non-member guests (`wanderer`, `scholar`, `herbalist`, `artisan`, `envoy`) and traders visit the sect, undergo gate authority screening (`admitted`, `restricted`, `rejected`), walk on the map, converse with disciples, and persist in `W.world.guestRegistry` without ever entering `W.npcs` or counting toward the 100-member bed cap.
   - **41 Authored Clue & Inheritance Templates (`docs/CLUE_SOURCE_CATALOG.json`)**: 8 ordinary/heritage leads + 22 non-innate legendary martial art leads + 11 legendary weapon leads, with `rootRumorId` provenance tracking, false rumor disproof, `personal` vs. `party_any` vs. `party_all` trial scopes, guardian combat, and replay-safe `VC.grantNamedStoryReward` receipts.
   - **11 Legendary Weapons across All 7 Weapon Families**: Grounded in Jin Yong and Gu Long research (`docs/LEGENDARY_WEAPON_RESEARCH.md`), with canonical `q`/`quality` normalization, `fixedStats`, `reqStrength` suitability gates, bounded `EFX_LEG_*` combat procs, and distinct visual silhouettes (`R.drawLegendaryWeaponVisual`).
   - Reports & Patch: `docs/VISITORS_CLUES_IMPLEMENTATION_REPORT.md`, `docs/LEGENDARY_WEAPON_RESEARCH.md`, `docs/CLUE_SOURCE_CATALOG.json`, `docs/VISITORS_CLUES_CODE_MAP.md`, `docs/CODEX_VISITORS_CLUES_HANDOFF.md`, and `docs/visitors_clues_weapons.patch`.

## 2. Hard Invariants Verified

- **`js/human_core.js` Byte Lock**: SHA-256 `a0d393284fb4b136848e5b80e12f3edd2c4f9437c419c793c2a7e75d881c0542` (`155:2f9c9dd7`), 0 bytes changed.
- **Full Test Suite (`node test/run_all.js`)**: **61 / 61 test groups PASS**.
- **Standalone Build (`JianghuSect_single.html`)**: **39 inline scripts**, 100% offline self-contained, verified via `node test/standalone.js`.
- **80-NPC Mobile Browser Performance (`node test/browser_mobile_perf.js`)**: **2.431 ms/tick** (`102.8×` speed capability, well under the `< 3.0 ms/tick` 48× budget).
