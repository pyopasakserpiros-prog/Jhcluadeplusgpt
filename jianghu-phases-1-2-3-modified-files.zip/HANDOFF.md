# HANDOFF.md

## Current Git State

- Base commit before Phase 1–3 development: `0218ae4ddb227422952ca933ea8b42a191836476`
- Primary project folder: `JianghuSect_v1.10`
- Development brief implemented in full: `docs/AGY_NEXT_DEVELOPMENT_BRIEF.md` (Phases 1, 2, and 3)
- Note on git operations: Built and verified inside an offline VM sandbox without remote GitHub access (`git push` / `git fetch` were not run; changes are ready as working-tree files and a clean unified git patch).

## Hard Lock (`human_core.js`)

Do not edit `JianghuSect_v1.10/js/human_core.js`.

- Expected SHA-256: `a0d393284fb4b136848e5b80e12f3edd2c4f9437c419c793c2a7e75d881c0542`
- Verified SHA-256: `a0d393284fb4b136848e5b80e12f3edd2c4f9437c419c793c2a7e75d881c0542`
- Runtime fingerprint: `155:2f9c9dd7`
- Lock test: `node test/core_lock.js` (`PASS`)

## Completed Scope (Phases 1–3)

### Phase 1: Recruitment, Talent Tiers, Facility Progression & 100-Member Housing Cap

- **Authoritative Dormitory & Facility Table (`SECT.FACILITY_SPECS` in `js/sect.js`)**:
  - `dorm_outer`: max level 5, beds `[24, 32, 40, 48, 56]`
  - `dorm_inner`: max level 4, beds `[14, 19, 24, 28]`
  - `dorm_core`: max level 3, beds `[8, 12, 16]`
  - Initial dormitory capacity: `24` (`dorm_outer` L1). Maximum total dormitory capacity: `56 + 28 + 16 = 100`.
  - Non-housing buildings (`mine`, `herb`, `farm`, `lumber`, `quarry`, `kitchen`, `hall`, `forge`, `alch`, `talisman`, `infirmary`, `pavilion`, `beast`, `prison`, `market`, `archive`, `wall`, `array`, `beacon`, `Bell`, `store`, `drill`, `medit`, `tree`) never contribute housing beds in `SECT.housingCapacity(W)` or `SIM.expandStations(W, b)` and respect per-type `maxLevel` (`3`, `4`, or `5`).
  - Steward upgrade AI (`SECT.upgradeBuilding` and `cognition.js`) evaluates all three dormitories (`dorm_outer`, `dorm_inner`, `dorm_core`) plus production/support buildings using `SECT.maxBuildingLevel(b)` and `SECT.upgradeCost(b)`.
- **5-Tier Applicant Generator (`SECT.TALENT_TIERS`, `SECT.rollApplicantTier`)**:
  - Implemented `COMMON`, `STEADY`, `GIFTED`, `PRODIGY`, and `HEAVENLY_CHILD` using seeded RNG (`W.rng`) and valid `HC.ROOT_BY_ID` keys (`DEFECTIVE`, `MORTAL`, `SPIRIT`, `TRUE`, `HEAVENLY`).
  - Integrated with `SIM.addNpc` (when `fromApplicant: true` or `useTalentTier: true`) and tracked under `W.sect.recruitmentStats`.
- **CA-Only Evaluation & Queue Hardening**:
  - `SECT.observableCapability(W, n)` evaluates current observable attributes, skills, cultivation stage, observable root quality, and observed traits with zero access to `n.pa`, `n.pot`, `n.potCeil`, or `n.latentTrait`.
  - `SECT.MAX_QUEUE = 6` enforced in `EXPED.recruitApplicants`, `SECT.recruitDrive`, `SECT.processApplicants`, and `SECT.sanitizeQueue`.
  - Recruitment halts cleanly when `SECT.memberOccupancy(W) >= SECT.housingCapacity(W)` or queue hits `6`, and `EXPED.daily` generates follow-up waves every 2 days during an active recruitment drive.
  - Officer availability check (`SECT.isOfficerAvailable`) blocks queue appraisal when the officer is dead, exiled, travelling, detained, resting in infirmary, or outside sect territory.

### Phase 2: Edit Hub (`#hudBottom` + `UI.rEdit`), Character Editor, Item Spawner & Personal Bag UI

- **Bottom Navigation & Responsive Layout (`index.html`, `css/style.css`, `js/ui.js`)**:
  - Added `button[data-nav="edit"]` (`✏️ แก้ไข`) to `#hudBottom` and tuned compact spacing so all 6 navigation tabs fit inside `360px`, `412px`, and `1280px` viewports with zero horizontal overflow.
  - Added quick entry buttons on `UI.rNpc` (`✏️ แก้ไขตัวละครนี้`, `✨ เสกของเข้าถุง`) and `UI.rSect('stock')` (`✨ เสกของเข้าคลัง`).
- **Character Editor (`SECT.EDITOR` in `js/sect.js`)**:
  - Supports editing identity (`givenName`, `surname`, `title`, `age`, `gender`, `role`, `rank`, `branch`, `preferRest`), all 8 attribute groups (`ca`/`pa`, `body`, `virtue`, `aptitude`, `pot`/`potCeil`, `skills`, `trait`, `root`), cultivation (`path`, `subpath`, `stage`, `xiu`, `breakthroughReady`), state (`hp`/`qi` ratios, `stamina`, `hunger`, `mood`, `stress`, `loyalty`, `injury`, `poison`, `bottleneck`), and economy (`contrib`, `silver`, `gold`).
  - Rejects direct arbitrary overrides of derived `hpMax`, `qiMax`, and `combatPower`; recalculates derived stats via `MARTIAL.derived(n)`.
  - Automatically reconciles mantras, techniques, specialization tracks, and incompatible equipped weapons (`unequippedGear` returned to `W.sect.gear`), records `formerNames` on rename, and pushes pre-edit snapshots to `W._editUndoStack` for `SECT.EDITOR.undoLastEdit(W)`.
- **Item Spawner & Anti-Minting Protection (`SECT.EDITOR.spawnItem`, `economy.js`, `knowledge.js`, `content.js`, `cpeco.js`)**:
  - Supports spawning `PROVISION`, `MATERIAL`, `PILL`, `CRAFTED_PILL`, `EQUIPMENT`, `TECH_MANUAL`, `CRYSTAL`, `SUB_MANUAL`, `RECIPE_SCROLL`, and `ORGAN` into either Sect Storage or an NPC's Personal Bag.
  - Marks spawned items with `playerSpawned: true` / `spawnedMats` / `spawnedPills` / `spawnedCrystals` / `spawnedTechs` / `spawnedSubManuals` / `spawnedRecipes` / `spawnedOrgans` so donating them back to the sect transfers the item without minting free contribution points (`contrib`) or silver.
- **Full Personal Inventory (`bag`) & Searchable Sect Stock (`stock`)**:
  - Expanded NPC personal inventory view in both `UI.rNpc` and `UI.rEdit('bag')` to display equipped weapons/armor/charms, provisions, materials, pills, crafted pills, equipment, technique manuals, crystals, sub-manuals, recipe scrolls, and organs with category/search/sort filters and direct equip/unequip/use/donate buttons.
  - Added search, category filter, tier filter, and sort controls to `UI.rSect('stock')`.

### Phase 3: Proactive Sect Stock Distribution, Precision Log Sub-Filters & Safe Entity Linking

- **Proactive Sect Stock Distribution (`SECT.distributeSectStock`, `SECT.evaluateStockDistribution`)**:
  - Evaluates spare sect equipment, non-basic cultivation/recovery pills, and specialization crystals daily (`CPE.daily`) while respecting reserve floors, rank/role access gates (`SECT.canAccessItem`), path/weapon/subpath compatibility, per-recipient cooldowns, and imperfect character-driven officer judgment.
  - Logs distributions with `txKind: 'gift'` (`[แจกจ่ายคลัง]`) and never spams daily basic ration/pill logs.
- **Precision Log Sub-Filters & Safe Entity Linking (`UI.rLog`, `UI.linkify`)**:
  - Added log sub-filters: `ทั้งหมด` (`all`), `ซ่อนโอสถพื้นฐาน` (`no_pill`), `เฉพาะของรางวัล/คลังแจก` (`gift`), `เฉพาะซื้อขาย` (`trade`), and `เฉพาะเสก/แก้ไข` (`spawn`).
  - Rebuilt `UI.linkify` as a single-pass positional scanner that never corrupts generated HTML attributes, links unique or full-name NPCs, resolves renamed NPCs via `formerNames`, skips ambiguous duplicate given names, and links buildings via `UI.inspectBuilding`.

## Verification Results

All 56 test suites in `test/run_all.js` passed:

- `node test/core_lock.js` -> `PASS`
- `node test/legacy_save.js` -> `PASS`
- `node test/save_integrity.js` -> `PASS`
- `node test/npc_cognition.js` -> `PASS`
- `node test/cave_pools.js` -> `PASS`
- `node test/outside_audit.js` -> `PASS`
- `node test/ui_content.js` -> `PASS`
- `node test/standalone.js` -> `PASS` (38 inline scripts in `JianghuSect_single.html`)
- `node test/phase1_recruitment_facilities.js` -> `PASS`
- `node test/phase2_edit_hub_inventory.js` -> `PASS`
- `node test/phase3_stock_distribution_log.js` -> `PASS`
- Real Headless Chromium Browser Suites (`NODE_PATH=/tmp/jianghu/JianghuSect_v1.10/node_modules`):
  - `node test/browser_mobile_perf.js` -> `PASS` (`35 NPC = 1.158ms/tick`, `60 NPC = 1.787ms/tick`, `80 NPC = 2.588ms/tick` < `3.0ms` budget; zero horizontal overflow on `360px`, `412px`, `1280px`)
  - `node test/skill_visual_browser.js` -> `PASS`
  - `node test/outside_visual_browser.js` -> `PASS`
  - `node test/input_cancellation.js` -> `PASS`
  - `node test/startup_ui.js` -> `PASS`
- Full runner: `NODE_PATH=/tmp/jianghu/JianghuSect_v1.10/node_modules node test/run_all.js` -> `Assertions: 56/56 groups passed.`
- Verification metrics saved to: `JianghuSect_v1.10/test/results/phase1_3_verification.json`

## Applying / Reviewing in Codex

1. Apply `jianghu-phases-1-2-3.patch` from the repository root (`git apply jianghu-phases-1-2-3.patch`) or extract `jianghu-phases-1-2-3-modified-files.zip` over the repository root.
2. Run `cd JianghuSect_v1.10 && node test/core_lock.js && node test/run_all.js`.
